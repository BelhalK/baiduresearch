.onAttach <-function (lib, pkg) {
  packageStartupMessage("     Loading library saemix, version 2.1, August 2017\n         please direct bugs, questions and feedback to belhal.karimi@inria.fr\n")
}
