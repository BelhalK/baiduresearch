export CUDA_VISIBLE_DEVICES=1


for decay in  True False
do
  for lr in 0.05 0.01 0.09
  do
    python -u run_nn_mnist.py --lr $lr --batch-size 128 --epochs 100 --repeat 5 --LR-decay $decay --decay-epoch 30 --optim adagrad
  done
done
