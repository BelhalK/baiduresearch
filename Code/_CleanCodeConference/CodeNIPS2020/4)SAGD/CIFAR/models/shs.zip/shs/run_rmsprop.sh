export CUDA_VISIBLE_DEVICES=3

for decay in  False
do
  for lr in 0.009 0.005 0.002
  do
    python -u run_nn_mnist.py --lr $lr --batch-size 128 --epochs 100 --repeat 5  --LR-decay $decay --decay-epoch 30 --optim rmsprop
  done
done
