

export CUDA_VISIBLE_DEVICES=0

for decay in   True
do
  for lr in 0.01 0.05
  do
    for noi in 0.01 
    do
      python -u run_nn_mnist.py --lr $lr --noise-coe $noi --batch-size 128 --epochs 100 --repeat 5  --LR-decay $decay --decay-epoch 30 --optim sagd_sparse
    done
  done
done
