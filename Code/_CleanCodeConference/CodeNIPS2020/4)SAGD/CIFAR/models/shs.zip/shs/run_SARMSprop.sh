export CUDA_VISIBLE_DEVICES=3

for decay in  True
do
  for lr in  0.001
  do
    for noi in 0.01 
    do
      python -u run_nn_mnist.py --lr $lr --noise-coe $noi --batch-size 128 --epochs 100 --repeat 5  --LR-decay $decay --decay-epoch 30 --optim SARMSprop
    done
  done
done
