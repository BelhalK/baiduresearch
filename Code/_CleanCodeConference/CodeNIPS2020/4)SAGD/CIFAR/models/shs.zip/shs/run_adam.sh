export CUDA_VISIBLE_DEVICES=2

for decay in  False
do
  for lr in 0.005 0.002 0.009
  do
    python -u run_nn_mnist.py --lr $lr --batch-size 128 --epochs 100 --repeat 5 --LR-decay $decay --decay-epoch 30 --optim adam
  done
done
