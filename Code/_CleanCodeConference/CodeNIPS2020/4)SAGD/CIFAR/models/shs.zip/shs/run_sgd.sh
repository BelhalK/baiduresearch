export CUDA_VISIBLE_DEVICES=2

for decay in  True 
do
  for lr in  0.1 0.01
  do
    for m in 0 0.1
    do
      python -u run_nn_mnist.py --lr 0.01 --batch-size 128 --epochs 100 --repeat 5 --momentum $m --LR-decay $decay --decay-epoch 30 --optim sgd
    done
  done
done
